Changelog
=========

Version 2.1 *(2018-04-04)*
----------------------------

 * Bug fixing

Version 2.0 *(2018-03-29)*
----------------------------

 * Redesign
 * Bug fixing

Version 1.0.1 *(2016-11-24)*
----------------------------

 * Translation updates


Version 1.0 *(2016-11-19)*
----------------------------

 * Initial Release
